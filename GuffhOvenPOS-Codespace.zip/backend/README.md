# Guffh Oven POS — Phase 1M Backend

Production backend foundation for the Android offline-first sync layer.

## Provider
This package targets Supabase/Postgres + Edge Functions. Supabase provides Postgres, authentication, backups and Row Level Security; the Android app can connect using HTTPS. RLS must be enabled on exposed tables. See the official Supabase Kotlin and RLS documentation.

## Deploy
1. Create a Supabase project.
2. Run `supabase/migrations/001_initial_sync.sql` in the SQL editor or via Supabase migrations.
3. Deploy the Edge Function `sync-push`.
4. Configure the Android app's backend URL to the function/API endpoint.
5. Provision the first device through a secure server-side process; do not put a service-role key in the APK.

## Security
- Device tokens are stored as SHA-256 hashes server-side.
- Raw service-role keys are never sent to Android.
- The sync endpoint rejects unauthenticated requests.
- Mutations are idempotent through a unique mutation ID.
- Server keeps the latest version plus mutation history.
- Conflict resolution is server-side last-write-wins using `updatedAt`, with device ID as a deterministic tie-breaker.

This package is deployable source, not a claim that a cloud project has been created or deployed.
