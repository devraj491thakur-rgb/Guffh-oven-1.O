import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
async function sha256(value: string) { const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)); return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2,"0")).join(""); }
Deno.serve(async (req) => {
  if (req.method !== "GET") return json({error:"method_not_allowed"},405);
  const auth = req.headers.get("authorization") ?? ""; if (!auth.startsWith("Bearer ")) return json({error:"missing_bearer_token"},401);
  const tokenHash = await sha256(auth.slice(7).trim());
  const {data: device} = await supabase.from("devices").select("device_id,active").eq("token_hash",tokenHash).maybeSingle();
  if (!device?.active) return json({error:"invalid_device"},401);
  const url = new URL(req.url); const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? 200),1),500);
  const {data,error} = await supabase.from("sync_records").select("entity_type,entity_id,payload,source_device_id,source_updated_at,server_updated_at").order("server_updated_at",{ascending:true}).limit(limit);
  if(error) return json({error:"read_failed",detail:error.message},500);
  await supabase.from("devices").update({last_seen_at:new Date().toISOString()}).eq("device_id",device.device_id);
  return json({deviceId:device.device_id,records:data ?? []});
});
