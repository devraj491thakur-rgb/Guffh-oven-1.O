import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });

async function sha256(value: string) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const auth = req.headers.get("authorization") ?? "";
  if (!auth.startsWith("Bearer ")) return json({ error: "missing_bearer_token" }, 401);
  const token = auth.slice("Bearer ".length).trim();
  if (!token) return json({ error: "missing_bearer_token" }, 401);

  const tokenHash = await sha256(token);
  const { data: device, error: deviceError } = await supabase
    .from("devices")
    .select("device_id, active")
    .eq("token_hash", tokenHash)
    .maybeSingle();
  if (deviceError || !device?.active) return json({ error: "invalid_device" }, 401);

  const body = await req.json();
  if (body.deviceId !== device.device_id || !Array.isArray(body.entries)) {
    return json({ error: "invalid_request" }, 400);
  }
  if (body.entries.length > 100) return json({ error: "batch_too_large" }, 413);

  let accepted = 0;
  let ignored = 0;

  for (const raw of body.entries) {
    const payload = JSON.parse(raw.payloadJson ?? "{}") as Record<string, unknown>;
    const mutationId = String(raw.id ?? "");
    const entityType = String(raw.entityType ?? "");
    const entityId = String(raw.entityId ?? "");
    const operation = String(raw.operation ?? "UPSERT");
    const updatedAt = Number(payload.updatedAt ?? payload.createdAt ?? raw.createdAt ?? 0);

    if (!mutationId || !entityType || !entityId || !Number.isFinite(updatedAt)) return json({ error: "invalid_entry" }, 400);

    const { data: existingMutation } = await supabase
      .from("sync_mutations")
      .select("mutation_id")
      .eq("mutation_id", mutationId)
      .maybeSingle();
    if (existingMutation) { ignored++; continue; }

    const { data: current } = await supabase
      .from("sync_records")
      .select("source_updated_at, source_device_id")
      .eq("entity_type", entityType)
      .eq("entity_id", entityId)
      .maybeSingle();

    const wins = !current || updatedAt > current.source_updated_at ||
      (updatedAt === current.source_updated_at && device.device_id > current.source_device_id);

    await supabase.from("sync_mutations").insert({
      mutation_id: mutationId,
      device_id: device.device_id,
      entity_type: entityType,
      entity_id: entityId,
      operation,
      payload: operation === "DELETE" ? null : payload,
      client_updated_at: updatedAt,
      accepted: wins,
    });

    if (wins) {
      if (operation === "DELETE") {
        await supabase.from("sync_records").delete().eq("entity_type", entityType).eq("entity_id", entityId);
      } else {
        const { error } = await supabase.from("sync_records").upsert({
          entity_type: entityType,
          entity_id: entityId,
          payload,
          source_device_id: device.device_id,
          source_updated_at: updatedAt,
          server_updated_at: new Date().toISOString(),
        });
        if (error) return json({ error: "storage_failed", detail: error.message }, 500);
      }
      accepted++;
    } else {
      ignored++;
    }
  }

  await supabase.from("devices").update({ last_seen_at: new Date().toISOString() }).eq("device_id", device.device_id);
  return json({ accepted, ignored, deviceId: device.device_id });
});
