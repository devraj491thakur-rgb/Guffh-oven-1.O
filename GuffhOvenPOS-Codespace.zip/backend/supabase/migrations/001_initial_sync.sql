create extension if not exists pgcrypto;

create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  device_id text not null unique,
  name text not null default 'Android POS',
  token_hash text not null unique,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz
);

create table if not exists public.sync_records (
  entity_type text not null,
  entity_id text not null,
  payload jsonb not null,
  source_device_id text not null,
  source_updated_at bigint not null,
  server_updated_at timestamptz not null default now(),
  primary key (entity_type, entity_id)
);

create table if not exists public.sync_mutations (
  mutation_id uuid primary key,
  device_id text not null,
  entity_type text not null,
  entity_id text not null,
  operation text not null check (operation in ('UPSERT','DELETE')),
  payload jsonb,
  client_updated_at bigint not null,
  accepted boolean not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_sync_mutations_created_at on public.sync_mutations(created_at);
create index if not exists idx_sync_records_type on public.sync_records(entity_type);

alter table public.devices enable row level security;
alter table public.sync_records enable row level security;
alter table public.sync_mutations enable row level security;

-- All client writes/reads go through the Edge Function using the service role.
-- No public Data API access is granted to these tables.
revoke all on public.devices from anon, authenticated;
revoke all on public.sync_records from anon, authenticated;
revoke all on public.sync_mutations from anon, authenticated;

grant all on public.devices to service_role;
grant all on public.sync_records to service_role;
grant all on public.sync_mutations to service_role;
