-- Phase 1O: authenticated device sync support.
-- Device bearer tokens are SHA-256 hashed in the database; plaintext tokens never persist server-side.
alter table public.devices add column if not exists business_id uuid;
alter table public.devices add column if not exists revoked_at timestamptz;
create index if not exists idx_sync_records_server_updated_at on public.sync_records(server_updated_at);
create index if not exists idx_devices_business_id on public.devices(business_id);
