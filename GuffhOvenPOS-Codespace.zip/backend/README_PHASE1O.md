# Guffh Oven POS — Phase 1O

Adds authenticated device sync and a pull endpoint for multi-device reconciliation.

## Flow
1. Android stores a device bearer token only in Android encrypted storage.
2. Every push/pull request sends `Authorization: Bearer <device-token>`.
3. Server stores only SHA-256(token), never the plaintext token.
4. Push remains idempotent by mutation UUID.
5. Conflicts use deterministic last-write-wins: newer client timestamp wins; equal timestamps use device ID as tie-breaker.
6. Pull returns canonical server records for the client to reconcile locally.

## Production requirements
- Provision tokens through an authenticated admin/device-registration workflow before enabling production sync.
- Set `SUPABASE_SERVICE_ROLE_KEY` only as an Edge Function secret.
- Bind devices to a business/tenant and enforce tenant filtering before production use.
- Add Supabase Auth/JWT or an equivalent authenticated provisioning service for owner operations.
- Implement client-side application of pulled records transactionally and record conflict notifications before declaring multi-device sync production-ready.
