# Phone-only build

This repository is intended to be built from GitHub/Codespaces without Android Studio on a phone.

## GitHub Actions
Open **Actions** → **Build Guffh Oven POS APK** → **Run workflow**. The generated debug APK is stored as an Actions artifact named `GuffhOvenPOS-debug-apk`.

## Codespaces
After opening the repository in Codespaces, verify that the repository root contains `app/`, `settings.gradle.kts`, and `build.gradle.kts`.
