# Phase 1M — Secure Cloud Backend Foundation

Added a deployable Supabase/Postgres backend package for the Android sync contract.

- Device registry with hashed device tokens
- Authenticated sync endpoint
- Idempotent mutation handling
- Server-side latest-record storage
- Deterministic conflict resolution
- Mutation history for audit/recovery
- RLS enabled with client Data API access revoked
- Service-role access restricted to the Edge Function

The backend is **not deployed** from this project. A Supabase project, device provisioning process, and production secrets still need to be configured.
