# Guffh Oven POS — Phase 1K

Android Kotlin + Jetpack Compose POS foundation.

Phase 1K adds the official WhatsApp Business Platform foundation:
- Admin WhatsApp Business settings
- Business number, Meta phone-number ID and API token fields
- WhatsApp default mode: ASK / AUTO_SEND / NEVER
- Per-bill send checkbox
- Full itemized bill message including custom charges and split payments
- Local WhatsApp SENT/FAILED status and audit entries
- Retry-ready bill state (bill is saved independently of WhatsApp)
- API token stored with Android encrypted shared preferences rather than the Room database

Important: connect this only to a Meta WhatsApp Business Platform account. The current app is a local/offline foundation; production cloud backend, secure server-side credential handling, approved templates where required, webhook handling, delivery status callbacks, rate-limit handling, and production testing remain before release.

This source has not been compiled into a production APK in this environment because no Gradle wrapper/build toolchain is available here.
