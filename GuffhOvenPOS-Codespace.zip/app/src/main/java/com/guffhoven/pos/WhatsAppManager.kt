package com.guffhoven.pos

import com.guffhoven.pos.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object WhatsAppManager {
    fun messageFor(bill: Bill, items: List<BillItem>, charges: List<CustomCharge>, payments: List<Payment>): String {
        val lines = buildString {
            append("Guffh Oven\n")
            append("Bill: ${bill.billNumber}\n")
            append("Date: ${formatDateTime(bill.createdAt)}\n\n")
            items.forEach { append("${it.itemNameSnapshot}${it.variantSnapshot?.let { v -> " • $v" } ?: ""} x${it.quantity} - ₹${it.lineTotalPaise / 100}\n") }
            charges.forEach { append("${it.description} x${it.quantity} - ₹${it.amountPaise * it.quantity / 100}\n") }
            append("\nTotal: ₹${bill.totalPaise / 100}\n")
            append("Order source: ${bill.platform}\n")
            append("Payment: ${payments.joinToString(" + ") { p -> "${p.method} ₹${p.amountPaise / 100}" }}\n\n")
            append("Thank you for visiting Guffh Oven!")
        }
        return lines
    }

    suspend fun send(settings: WhatsAppSettings, recipient: String, message: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (!settings.enabled) return@withContext Result.failure(IllegalStateException("WhatsApp integration is disabled"))
        if (settings.accessToken.isBlank() || settings.phoneNumberId.isBlank()) return@withContext Result.failure(IllegalStateException("WhatsApp API credentials are not configured"))
        if (!recipient.matches(Regex("\\d{10}"))) return@withContext Result.failure(IllegalArgumentException("Recipient phone number is invalid"))
        try {
            val url = URL("${settings.apiBaseUrl.trimEnd('/')}/v23.0/${settings.phoneNumberId}/messages")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Authorization", "Bearer ${settings.accessToken}")
                setRequestProperty("Content-Type", "application/json")
                connectTimeout = 15_000
                readTimeout = 20_000
            }
            val body = JSONObject().apply {
                put("messaging_product", "whatsapp")
                put("to", "91$recipient")
                put("type", "text")
                put("text", JSONObject().put("preview_url", false).put("body", message))
            }.toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            if (code in 200..299) Result.success(Unit) else Result.failure(IllegalStateException("WhatsApp API returned HTTP $code"))
        } catch (e: Exception) { Result.failure(e) }
    }
}
