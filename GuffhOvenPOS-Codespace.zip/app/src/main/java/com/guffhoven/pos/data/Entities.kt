package com.guffhoven.pos.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "staff")
data class Staff(
    @PrimaryKey val id: String,
    val name: String,
    val username: String,
    val pinHash: String,
    val role: String, // ADMIN or STAFF
    val active: Boolean = true,
    val canCreateBills: Boolean = true,
    val canAddCustomCharges: Boolean = true,
    val canEditRecentBills: Boolean = true,
    val canPrint: Boolean = true,
    val canSendWhatsApp: Boolean = true
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String,
    val name: String?,
    val phone: String?,
    val anonymous: Boolean,
    val createdAt: Long,
    val firstVisitAt: Long?,
    val lastVisitAt: Long?,
    val totalVisits: Int,
    val totalSpendingPaise: Long
)

@Entity(tableName = "menu_items")
data class MenuItem(
    @PrimaryKey val id: String,
    val category: String,
    val name: String,
    val variant: String?,
    val pricePaise: Long,
    val bestseller: Boolean,
    val active: Boolean = true,
    val sortOrder: Int = 0
)

@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey val id: String,
    val billNumber: String,
    val customerId: String?,
    val platform: String,
    val subtotalPaise: Long,
    val customChargesPaise: Long,
    val totalPaise: Long,
    val createdByStaffId: String,
    val updatedByStaffId: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val syncStatus: String = "PENDING",
    val printStatus: String = "PENDING",
    val whatsappStatus: String = "NOT_SENT"
)

@Entity(tableName = "bill_items")
data class BillItem(
    @PrimaryKey val id: String,
    val billId: String,
    val menuItemId: String?,
    val itemNameSnapshot: String,
    val variantSnapshot: String?,
    val quantity: Int,
    val unitPricePaise: Long,
    val lineTotalPaise: Long
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey val id: String,
    val billId: String,
    val method: String,
    val amountPaise: Long
)

@Entity(tableName = "custom_charges")
data class CustomCharge(
    @PrimaryKey val id: String,
    val billId: String,
    val description: String,
    val quantity: Int,
    val amountPaise: Long,
    val addedByStaffId: String,
    val createdAt: Long
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey val id: String,
    val billId: String?,
    val actorStaffId: String,
    val action: String,
    val details: String,
    val createdAt: Long
)

@Entity(tableName = "whatsapp_settings")
data class WhatsAppSettings(
    @PrimaryKey val id: Int = 1,
    val businessPhone: String = "",
    val accessToken: String = "",
    val phoneNumberId: String = "",
    val defaultMode: String = "ASK",
    val enabled: Boolean = false,
    val apiBaseUrl: String = "https://graph.facebook.com"
)

@Entity(tableName = "sync_settings")
data class SyncSettings(
    @PrimaryKey val id: Int = 1,
    val enabled: Boolean = false,
    val serverUrl: String = "",
    val deviceId: String = "",
    val lastSyncAt: Long? = null,
    val lastSyncStatus: String = "NEVER"
)

@Entity(tableName = "sync_queue")
data class SyncQueueEntry(
    @PrimaryKey val id: String,
    val entityType: String,
    val entityId: String,
    val operation: String,
    val payloadJson: String,
    val createdAt: Long,
    val attempts: Int = 0,
    val status: String = "PENDING",
    val lastError: String? = null
)
