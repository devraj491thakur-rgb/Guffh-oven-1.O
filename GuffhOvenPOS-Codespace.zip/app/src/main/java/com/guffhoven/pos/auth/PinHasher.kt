package com.guffhoven.pos.auth

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object PinHasher {
    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH = 256

    fun create(pin: String): String {
        require(pin.length in 4..6 && pin.all(Char::isDigit)) { "PIN must be 4 to 6 digits" }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin, salt)
        return "v1:${hex(salt)}:${hex(hash)}"
    }

    fun verify(pin: String, encoded: String): Boolean {
        return try {
            val parts = encoded.split(":")
            if (parts.size != 3 || parts[0] != "v1") return false
            val salt = parts[1].hexBytes()
            val expected = parts[2].hexBytes()
            MessageDigest.isEqual(expected, derive(pin, salt))
        } catch (_: Exception) { false }
    }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it) }
    private fun String.hexBytes() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}
