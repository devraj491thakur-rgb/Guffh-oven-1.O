package com.guffhoven.pos

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object SecureSecrets {
    private const val PREFS = "guffh_secure_secrets"
    private const val WHATSAPP_TOKEN = "whatsapp_access_token"
    private const val SYNC_TOKEN = "sync_access_token"

    private fun prefs(context: Context) = EncryptedSharedPreferences.create(
        context,
        PREFS,
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getWhatsAppToken(context: Context): String = prefs(context).getString(WHATSAPP_TOKEN, "") ?: ""
    fun setWhatsAppToken(context: Context, token: String) { prefs(context).edit().putString(WHATSAPP_TOKEN, token).apply() }
    fun getSyncToken(context: Context): String = prefs(context).getString(SYNC_TOKEN, "") ?: ""
    fun setSyncToken(context: Context, token: String) { prefs(context).edit().putString(SYNC_TOKEN, token).apply() }
    fun clearSyncToken(context: Context) { prefs(context).edit().remove(SYNC_TOKEN).apply() }
}
