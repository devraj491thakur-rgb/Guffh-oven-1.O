package com.guffhoven.pos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.guffhoven.pos.auth.PinHasher
import com.guffhoven.pos.data.*
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.Calendar

private enum class SessionRole { ADMIN, STAFF }

data class StaffSession(val staff: Staff)

data class CartLine(val item: MenuItem, val quantity: Int)
data class ChargeDraft(val description: String, val quantity: Int, val amountPaise: Long)

class MainActivity : ComponentActivity() {
    private var syncConnectivity: SyncConnectivity? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        syncConnectivity = SyncConnectivity(this, db).also { it.start() }
        setContent { GuffhOvenApp(db) }
    }
    override fun onDestroy() {
        syncConnectivity?.stop()
        super.onDestroy()
    }
}

@Composable
private fun GuffhOvenApp(db: AppDatabase) {
    var configured by remember { mutableStateOf<Boolean?>(null) }
    var session by remember { mutableStateOf<StaffSession?>(null) }
    LaunchedEffect(Unit) { configured = db.staffDao().count() > 0 }
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            when {
                configured == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                session?.staff?.role == "ADMIN" -> AdminHome(db, onLogout = { session = null })
                session?.staff?.role == "STAFF" -> StaffHome(db, session!!.staff, onLogout = { session = null })
                configured == false -> FirstAdminSetup(onCreated = { configured = true })
                else -> LoginScreen(db = db, onLoggedIn = { session = StaffSession(it) })
            }
        }
    }
}

@Composable
private fun FirstAdminSetup(onCreated: () -> Unit) {
    val db = remember { AppDatabase.get(androidx.compose.ui.platform.LocalContext.current) }
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }; var username by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }; var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }; var saving by remember { mutableStateOf(false) }
    AuthCard(title = "First-time setup") {
        Text("Create the owner/admin account. No demo PIN is built into the app.")
        OutlinedTextField(name,{name=it},label={Text("Owner name")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(username,{username=it},label={Text("Username")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(pin,{if(it.length<=6&&it.all(Char::isDigit))pin=it},label={Text("PIN (4–6 digits)")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
        OutlinedTextField(confirm,{if(it.length<=6&&it.all(Char::isDigit))confirm=it},label={Text("Confirm PIN")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
        if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=!saving,onClick={
            if(name.isBlank()||username.isBlank()){error="Name and username are required";return@Button}
            if(pin.length !in 4..6){error="PIN must contain 4–6 digits";return@Button}; if(pin!=confirm){error="PINs do not match";return@Button}
            saving=true; scope.launch { try { if(db.staffDao().findByUsername(username.trim())!=null){error="Username already exists";saving=false;return@launch}; db.staffDao().insert(Staff(UUID.randomUUID().toString(),name.trim(),username.trim(),PinHasher.create(pin),"ADMIN",true));onCreated() } catch(_:Exception){error="Could not create account"};saving=false }
        },modifier=Modifier.fillMaxWidth()){Text(if(saving)"Creating…" else "CREATE ADMIN ACCOUNT")}
    }
}

@Composable
private fun LoginScreen(db: AppDatabase,onLoggedIn:(Staff)->Unit){
    val scope=rememberCoroutineScope(); var username by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};var loading by remember{mutableStateOf(false)}
    AuthCard(title="POS & Billing System"){
        OutlinedTextField(username,{username=it},label={Text("Username")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(pin,{if(it.length<=6&&it.all(Char::isDigit))pin=it},label={Text("PIN")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=!loading,onClick={loading=true;error="";scope.launch{val s=db.staffDao().findByUsername(username.trim());if(s==null||!s.active||!PinHasher.verify(pin,s.pinHash)){error="Invalid username or PIN";loading=false}else{onLoggedIn(s);loading=false}}},modifier=Modifier.fillMaxWidth()){Text(if(loading)"Checking…" else "LOGIN")}
    }
}

@Composable private fun AuthCard(title:String,content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxWidth().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("GUFFH OVEN",style=MaterialTheme.typography.headlineLarge);Text(title,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(28.dp));Column(verticalArrangement=Arrangement.spacedBy(12.dp),content=content,modifier=Modifier.widthIn(max=420.dp))}}

@Composable private fun AdminHome(db:AppDatabase,onLogout:()->Unit){
    var screen by remember{mutableStateOf("home")}
    when(screen){
        "staff" -> StaffManagement(db,{screen="home"})
        "menu" -> MenuManagement(db,{screen="home"})
        "orders" -> OrderHistory(db,{screen="home"})
        "customers" -> CustomerManagement(db,{screen="home"})
        "dashboard" -> SalesDashboard(db,{screen="home"})
        "reports" -> ReportsScreen(db,{screen="home"})
        "printer" -> PrinterSettingsScreen({screen="home"})
        "whatsapp" -> WhatsAppSettingsScreen(db, {screen="home"})
        else -> Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.spacedBy(18.dp),horizontalAlignment=Alignment.CenterHorizontally){
            Text("GUFFH OVEN",style=MaterialTheme.typography.headlineLarge)
            Text("ADMIN DASHBOARD",style=MaterialTheme.typography.headlineSmall)
            Text("Live sales dashboard from saved bills")
            Button(onClick={screen="dashboard"},modifier=Modifier.fillMaxWidth().widthIn(max=420.dp)){Text("SALES DASHBOARD") }
            Button(onClick={screen="reports"},modifier=Modifier.fillMaxWidth().widthIn(max=420.dp)){Text("REPORTS & FILTERS") }
            Button(onClick={screen="orders"},modifier=Modifier.fillMaxWidth().widthIn(max=420.dp)){Text("ORDER HISTORY")}
            Button(onClick={screen="customers"},modifier=Modifier.fillMaxWidth().widthIn(max=420.dp)){Text("CUSTOMER MANAGEMENT")}
            Button(onClick={screen="staff"},modifier=Modifier.fillMaxWidth().widthIn(max=420.dp)){Text("STAFF MANAGEMENT")}
            Button(onClick={screen="menu"},modifier=Modifier.fillMaxWidth().widthIn(max=420.dp)){Text("MENU MANAGEMENT")}
            Button(onClick={screen="whatsapp"},modifier=Modifier.fillMaxWidth().widthIn(max=420.dp)){Text("WHATSAPP BUSINESS")}
            Button(onClick={screen="printer"},modifier=Modifier.fillMaxWidth().widthIn(max=420.dp)){Text("PRINTER SETTINGS")}
            Button(onClick={screen="sync"},modifier=Modifier.fillMaxWidth().widthIn(max=420.dp)){Text("CLOUD BACKUP & SYNC")}
            OutlinedButton(onClick=onLogout){Text("LOG OUT")}
        }
    }
}

@Composable
private fun CloudSyncSettingsScreen(db: AppDatabase, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var enabled by remember { mutableStateOf(false) }
    var serverUrl by remember { mutableStateOf("") }
    var deviceId by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("NEVER") }
    var pending by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("") }
    fun load() = scope.launch {
        val s = db.syncSettingsDao().get()
        enabled = s?.enabled ?: false
        serverUrl = s?.serverUrl ?: ""
        deviceId = s?.deviceId ?: SyncManager(context, db).deviceId()
        status = s?.lastSyncStatus ?: "NEVER"
        pending = db.syncQueueDao().pendingCount()
    }
    LaunchedEffect(Unit) { load() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Text("CLOUD BACKUP & SYNC", style=MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick=onBack) { Text("BACK") }
        }
        Text("Offline-first: bills remain on the device and wait in the sync queue when the internet/cloud is unavailable.")
        Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(checked=enabled, onCheckedChange={enabled=it}); Text("Enable cloud synchronization") }
        OutlinedTextField(serverUrl, {serverUrl=it}, label={Text("Backend HTTPS URL")}, placeholder={Text("https://your-api.example.com")}, modifier=Modifier.fillMaxWidth())
        OutlinedTextField(deviceId, {}, readOnly=true, label={Text("Device ID")}, modifier=Modifier.fillMaxWidth())
        DashboardCard("Pending sync records", pending.toString())
        DashboardCard("Last sync status", status)
        if (message.isNotBlank()) Text(message)
        Button(onClick={ scope.launch { val current=db.syncSettingsDao().get() ?: SyncSettings(deviceId=deviceId); db.syncSettingsDao().save(current.copy(enabled=enabled, serverUrl=serverUrl.trim(), deviceId=deviceId)); message="Sync settings saved."; load() } }, modifier=Modifier.fillMaxWidth()) { Text("SAVE SYNC SETTINGS") }
        OutlinedButton(onClick={ scope.launch { val result=SyncManager(context, db).syncOnce(); message=result.fold({"Sync completed: ${it} records uploaded."},{"Sync failed: ${it.message ?: "unknown error"}"}); load() } }, modifier=Modifier.fillMaxWidth()) { Text("SYNC NOW") }
        Text("Production note: this app expects a secure Guffh Oven backend at the configured HTTPS URL. No cloud credentials are hard-coded into the APK.", style=MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SalesDashboard(db: AppDatabase, onBack: () -> Unit) {
    var loading by remember { mutableStateOf(true) }
    var summary by remember { mutableStateOf(SalesSummary(0, 0)) }
    var outlet by remember { mutableStateOf(0L) }
    var online by remember { mutableStateOf(0L) }
    var payments by remember { mutableStateOf<List<PaymentSummary>>(emptyList()) }
    val scope = rememberCoroutineScope()

    fun startOfToday(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }
    fun refresh() = scope.launch {
        loading = true
        val start = startOfToday(); val end = start + 24L * 60L * 60L * 1000L
        summary = db.billDao().salesSummary(start, end)
        outlet = db.billDao().outletSales(start, end)
        online = db.billDao().onlineSales(start, end)
        payments = db.paymentDao().summary(start, end)
        loading = false
    }
    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Text("SALES DASHBOARD", style=MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick=onBack) { Text("BACK") }
        }
        Text("Today — actual saved bills", style=MaterialTheme.typography.bodyMedium)
        if (loading) CircularProgressIndicator()
        else {
            DashboardCard("Today's Sales", "₹${summary.totalPaise / 100}")
            DashboardCard("Bills", summary.billCount.toString())
            DashboardCard("Average Bill", if(summary.billCount == 0) "₹0" else "₹${summary.totalPaise / summary.billCount / 100}")
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                DashboardCard("Outlet", "₹${outlet / 100}", Modifier.weight(1f))
                DashboardCard("Online", "₹${online / 100}", Modifier.weight(1f))
            }
            Text("PAYMENT TOTALS", style=MaterialTheme.typography.titleMedium)
            if (payments.isEmpty()) Text("No payments recorded today")
            payments.forEach { DashboardCard(it.method, "₹${it.totalPaise / 100}") }
            OutlinedButton(onClick={refresh()}, modifier=Modifier.fillMaxWidth()) { Text("REFRESH") }
        }
    }
}

@Composable
private fun ReportsScreen(db: AppDatabase, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    var range by remember { mutableStateOf("Today") }
    var start by remember { mutableStateOf(startOfDayMillis()) }
    var end by remember { mutableStateOf(startOfDayMillis() + DAY_MS) }
    var summary by remember { mutableStateOf(SalesSummary(0, 0)) }
    var payments by remember { mutableStateOf<List<PaymentSummary>>(emptyList()) }
    var platforms by remember { mutableStateOf<List<PaymentSummary>>(emptyList()) }
    var products by remember { mutableStateOf<List<ProductSalesSummary>>(emptyList()) }
    var staffSales by remember { mutableStateOf<List<StaffSalesSummary>>(emptyList()) }
    var staffNames by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var loading by remember { mutableStateOf(true) }

    fun refresh() = scope.launch {
        loading = true
        summary = db.billDao().salesSummary(start, end)
        payments = db.paymentDao().summary(start, end)
        platforms = db.billDao().platformSales(start, end)
        products = db.billDao().productSales(start, end)
        staffSales = db.billDao().staffSales(start, end)
        staffNames = staffSales.associate { it.staffId to (db.staffDao().findById(it.staffId)?.name ?: it.staffId.take(8)) }
        loading = false
    }
    LaunchedEffect(start, end) { refresh() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("REPORTS & FILTERS", style = MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick = onBack) { Text("BACK") }
        }
        Text("All figures come from saved bills.")
        ChoiceRow(listOf("Today", "Last 7 Days", "Last 30 Days"), range) {
            range = it
            when (it) {
                "Today" -> { start = startOfDayMillis(); end = start + DAY_MS }
                "Last 7 Days" -> { start = startOfDayMillis() - 6 * DAY_MS; end = startOfDayMillis() + DAY_MS }
                else -> { start = startOfDayMillis() - 29 * DAY_MS; end = startOfDayMillis() + DAY_MS }
            }
        }
        OutlinedButton(onClick = {
            val c = Calendar.getInstance()
            android.app.DatePickerDialog(context, { _, y, m, d ->
                val chosen = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
                start = chosen.timeInMillis
                end = start + DAY_MS
                range = "Custom day"
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }, modifier = Modifier.fillMaxWidth()) { Text("CUSTOM DATE") }

        if (loading) CircularProgressIndicator() else {
            DashboardCard("Sales", "₹${summary.totalPaise / 100}")
            DashboardCard("Bills", summary.billCount.toString())
            DashboardCard("Average Bill", if (summary.billCount == 0) "₹0" else "₹${summary.totalPaise / summary.billCount / 100}")

            Text("PAYMENT-WISE", style = MaterialTheme.typography.titleMedium)
            if (payments.isEmpty()) Text("No payments in this period")
            payments.forEach { DashboardCard(it.method, "₹${it.totalPaise / 100}") }

            Text("PLATFORM / ORDER SOURCE", style = MaterialTheme.typography.titleMedium)
            if (platforms.isEmpty()) Text("No platform sales in this period")
            platforms.forEach { DashboardCard(it.method, "₹${it.totalPaise / 100}") }

            Text("TOP PRODUCTS", style = MaterialTheme.typography.titleMedium)
            if (products.isEmpty()) Text("No item sales in this period")
            products.take(10).forEachIndexed { i, p ->
                Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${i + 1}. ${p.itemNameSnapshot} × ${p.quantity}", Modifier.weight(1f))
                    Text("₹${p.totalPaise / 100}")
                } }
            }

            Text("STAFF-WISE ACTIVITY", style = MaterialTheme.typography.titleMedium)
            if (staffSales.isEmpty()) Text("No staff activity in this period")
            staffSales.forEach { s -> DashboardCard(staffNames[s.staffId] ?: s.staffId, "${s.billCount} bills • ₹${s.totalPaise / 100}") }
            OutlinedButton(onClick = { refresh() }, modifier = Modifier.fillMaxWidth()) { Text("REFRESH") }
        }
    }
}

private const val DAY_MS = 24L * 60L * 60L * 1000L
private fun startOfDayMillis(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

@Composable
private fun DashboardCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style=MaterialTheme.typography.labelLarge)
            Text(value, style=MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
private fun StaffManagement(db: AppDatabase, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var staff by remember { mutableStateOf<List<Staff>>(emptyList()) }
    var selected by remember { mutableStateOf<Staff?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    fun refresh() = scope.launch { staff = db.staffDao().all() }
    LaunchedEffect(Unit) { refresh() }

    if (showAdd) {
        StaffEditor(
            title = "Add Staff",
            existing = null,
            onCancel = { showAdd = false },
            onSave = { n, u, p, per ->
                scope.launch {
                    if (db.staffDao().findByUsername(u.trim()) == null) {
                        db.staffDao().insert(Staff(UUID.randomUUID().toString(), n.trim(), u.trim(), PinHasher.create(p), "STAFF", true, per[0], per[1], per[2], per[3], per[4]))
                        showAdd = false
                        refresh()
                    }
                }
            }
        )
        return
    }

    selected?.let { current ->
        StaffEditor(
            title = "Edit Staff",
            existing = current,
            onCancel = { selected = null },
            onSave = { n, u, p, per ->
                scope.launch {
                    val duplicate = db.staffDao().findByUsername(u.trim())
                    if (duplicate == null || duplicate.id == current.id) {
                        db.staffDao().update(current.copy(
                            name = n.trim(), username = u.trim(),
                            pinHash = if (p.isBlank()) current.pinHash else PinHasher.create(p),
                            canCreateBills = per[0], canAddCustomCharges = per[1],
                            canEditRecentBills = per[2], canPrint = per[3], canSendWhatsApp = per[4]
                        ))
                        selected = null
                        refresh()
                    }
                }
            }
        )
        return
    }

    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("STAFF MANAGEMENT", style = MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick = onBack) { Text("BACK") }
        }
        Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ ADD STAFF") }
        staff.forEach { member ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(member.name, style = MaterialTheme.typography.titleLarge)
                        Text(if (member.active) "ACTIVE" else "INACTIVE")
                    }
                    Text("@${member.username} • ${member.role}")
                    Text(permissionSummary(member))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { selected = member }) { Text("EDIT") }
                        OutlinedButton(onClick = {
                            scope.launch {
                                db.staffDao().update(member.copy(active = !member.active))
                                refresh()
                            }
                        }) { Text(if (member.active) "DEACTIVATE" else "ACTIVATE") }
                    }
                }
            }
        }
    }
}

private fun permissionSummary(s:Staff)=listOfNotNull(if(s.canCreateBills)"Bills"else null,if(s.canAddCustomCharges)"Custom charges"else null,if(s.canEditRecentBills)"Edit recent"else null,if(s.canPrint)"Print"else null,if(s.canSendWhatsApp)"WhatsApp"else null).joinToString(", ").ifBlank{"No billing permissions"}

@Composable private fun StaffEditor(title:String,existing:Staff?,onCancel:()->Unit,onSave:(String,String,String,List<Boolean>)->Unit){var name by remember(existing){mutableStateOf(existing?.name.orEmpty())};var username by remember(existing){mutableStateOf(existing?.username.orEmpty())};var pin by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};var a by remember(existing){mutableStateOf(existing?.canCreateBills?:true)};var b by remember(existing){mutableStateOf(existing?.canAddCustomCharges?:true)};var c by remember(existing){mutableStateOf(existing?.canEditRecentBills?:true)};var d by remember(existing){mutableStateOf(existing?.canPrint?:true)};var e by remember(existing){mutableStateOf(existing?.canSendWhatsApp?:true)};Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){Text(title,style=MaterialTheme.typography.headlineSmall);OutlinedTextField(name,{name=it},label={Text("Staff name")},singleLine=true,modifier=Modifier.fillMaxWidth());OutlinedTextField(username,{username=it},label={Text("Username")},singleLine=true,modifier=Modifier.fillMaxWidth());OutlinedTextField(pin,{if(it.length<=6&&it.all(Char::isDigit))pin=it},label={Text(if(existing==null)"PIN (4–6 digits)" else "New PIN (blank = keep current)")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth());Text("Permissions",style=MaterialTheme.typography.titleMedium);PermissionSwitch("Create bills",a){a=it};PermissionSwitch("Add custom charges",b){b=it};PermissionSwitch("Edit permitted/recent bills",c){c};PermissionSwitch("Print bills",d){d};PermissionSwitch("Send bills on WhatsApp",e){e};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){OutlinedButton(onClick=onCancel,modifier=Modifier.weight(1f)){Text("CANCEL")};Button(onClick={if(name.isBlank()||username.isBlank())error="Name and username are required" else if(existing==null&&pin.length !in 4..6)error="PIN must contain 4–6 digits" else if(existing!=null&&pin.isNotBlank()&&pin.length !in 4..6)error="New PIN must contain 4–6 digits" else onSave(name,username,pin,listOf(a,b,c,d,e))},modifier=Modifier.weight(1f)){Text("SAVE")}}}}
@Composable private fun PermissionSwitch(label:String,checked:Boolean,onCheckedChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text(label);Switch(checked,onCheckedChange)}}


@Composable
private fun MenuManagement(db: AppDatabase, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<MenuItem>>(emptyList()) }
    var editorItem by remember { mutableStateOf<MenuItem?>(null) }
    var adding by remember { mutableStateOf(false) }
    var showInactive by remember { mutableStateOf(true) }

    fun refresh() = scope.launch { items = db.menuItemDao().all() }
    LaunchedEffect(Unit) { refresh() }

    if (adding || editorItem != null) {
        MenuItemEditor(
            existing = editorItem,
            onCancel = { adding = false; editorItem = null },
            onSave = { category, name, variant, pricePaise, bestseller, active, sortOrder ->
                scope.launch {
                    if (editorItem == null) {
                        db.menuItemDao().insert(MenuItem(UUID.randomUUID().toString(), category, name, variant, pricePaise, bestseller, active, sortOrder))
                    } else {
                        db.menuItemDao().update(editorItem!!.copy(category=category,name=name,variant=variant,pricePaise=pricePaise,bestseller=bestseller,active=active,sortOrder=sortOrder))
                    }
                    adding=false; editorItem=null; refresh()
                }
            }
        )
        return
    }

    val visible = items.filter { showInactive || it.active }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Text("MENU MANAGEMENT",style=MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick=onBack){Text("BACK")}
        }
        Text("Add your approved final Guffh Oven menu here. Old bills keep their original item name and price.",style=MaterialTheme.typography.bodyMedium)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
            Button(onClick={adding=true}){Text("+ ADD ITEM")}
            FilterChip(selected=showInactive,onClick={showInactive=!showInactive},label={Text("Show inactive")})
        }
        if(visible.isEmpty()) Text("No menu items yet.")
        visible.forEach { item ->
            Card(Modifier.fillMaxWidth()){
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                        Column(Modifier.weight(1f)){
                            Text(if(item.bestseller) "⭐ ${item.name}" else item.name,style=MaterialTheme.typography.titleMedium)
                            Text(listOfNotNull(item.category.takeIf{it.isNotBlank()},item.variant?.takeIf{it.isNotBlank()}).joinToString(" • "))
                        }
                        Text("₹${item.pricePaise/100}",style=MaterialTheme.typography.titleMedium)
                    }
                    Text(if(item.active) "ACTIVE" else "INACTIVE",style=MaterialTheme.typography.labelSmall)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        OutlinedButton(onClick={editorItem=item},modifier=Modifier.weight(1f)){Text("EDIT")}
                        OutlinedButton(onClick={scope.launch { db.menuItemDao().update(item.copy(active=!item.active)); refresh() }},modifier=Modifier.weight(1f)){Text(if(item.active) "DISABLE" else "ENABLE")}
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuItemEditor(existing: MenuItem?, onCancel: () -> Unit, onSave: (String,String,String?,Long,Boolean,Boolean,Int)->Unit) {
    var category by remember(existing){mutableStateOf(existing?.category ?: "")}
    var name by remember(existing){mutableStateOf(existing?.name ?: "")}
    var variant by remember(existing){mutableStateOf(existing?.variant ?: "")}
    var price by remember(existing){mutableStateOf(if(existing==null) "" else (existing.pricePaise/100).toString())}
    var sortOrder by remember(existing){mutableStateOf(existing?.sortOrder?.toString() ?: "0")}
    var bestseller by remember(existing){mutableStateOf(existing?.bestseller ?: false)}
    var active by remember(existing){mutableStateOf(existing?.active ?: true)}
    var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text(if(existing==null) "ADD MENU ITEM" else "EDIT MENU ITEM",style=MaterialTheme.typography.headlineSmall)
        OutlinedTextField(category,{category=it},label={Text("Category")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(name,{name=it},label={Text("Item name")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(variant,{variant=it},label={Text("Variant / size (optional)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(price,{if(it.matches(Regex("\\d{0,6}(\\.\\d{0,2})?")))price=it},label={Text("Price (₹)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(sortOrder,{if(it.all(Char::isDigit))sortOrder=it},label={Text("Sort order")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("Bestseller ⭐");Switch(bestseller,{bestseller=it})}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("Active");Switch(active,{active=it})}
        if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
            OutlinedButton(onClick=onCancel,modifier=Modifier.weight(1f)){Text("CANCEL")}
            Button(onClick={
                val p=(price.toDoubleOrNull()?.times(100))?.toLong()
                if(category.isBlank()||name.isBlank()) error="Category and item name are required"
                else if(p==null||p<0) error="Enter a valid price"
                else onSave(category.trim(),name.trim(),variant.trim().ifBlank{null},p,bestseller,active,sortOrder.toIntOrNull() ?: 0)
            },modifier=Modifier.weight(1f)){Text("SAVE")}
        }
    }
}



@Composable
private fun CustomerManagement(db: AppDatabase, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var customers by remember { mutableStateOf<List<Customer>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Customer?>(null) }

    fun refresh() = scope.launch {
        customers = if (query.trim().isBlank()) db.customerDao().allNamed() else db.customerDao().search("%${query.trim()}%")
    }
    LaunchedEffect(query) { refresh() }

    selected?.let { customer ->
        CustomerProfile(db, customer, onBack = { selected = null })
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("CUSTOMER MANAGEMENT", style = MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick = onBack) { Text("BACK") }
        }
        OutlinedTextField(query, { query = it }, label = { Text("Search name or phone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Customer database is admin-only. Anonymous/no-phone records are kept separate and are not merged into named customers.")
        if (customers.isEmpty()) Text("No matching customers yet.")
        customers.forEach { customer ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(customer.name ?: "Unnamed customer", style = MaterialTheme.typography.titleMedium)
                        Text("${customer.totalVisits} visits")
                    }
                    Text(customer.phone ?: "No phone")
                    Text("Total spending: ₹${customer.totalSpendingPaise / 100}")
                    Text("Last visit: ${customer.lastVisitAt?.let(::formatDateTime) ?: "—"}")
                    Button(onClick = { selected = customer }, modifier = Modifier.fillMaxWidth()) { Text("VIEW PROFILE & ORDER HISTORY") }
                }
            }
        }
    }
}

@Composable
private fun CustomerProfile(db: AppDatabase, customer: Customer, onBack: () -> Unit) {
    var bills by remember { mutableStateOf<List<Bill>>(emptyList()) }
    LaunchedEffect(customer.id) { bills = db.billDao().forCustomer(customer.id) }
    val average = if (customer.totalVisits > 0) customer.totalSpendingPaise / customer.totalVisits else 0L
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("CUSTOMER PROFILE", style = MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick = onBack) { Text("BACK") }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(customer.name ?: "Unnamed customer", style = MaterialTheme.typography.titleLarge)
                Text("Phone: ${customer.phone ?: "Not shared"}")
                Text("Visits: ${customer.totalVisits}")
                Text("Total spending: ₹${customer.totalSpendingPaise / 100}")
                Text("Average bill: ₹${average / 100}")
                Text("First visit: ${customer.firstVisitAt?.let(::formatDateTime) ?: "—"}")
                Text("Last visit: ${customer.lastVisitAt?.let(::formatDateTime) ?: "—"}")
            }
        }
        Text("ORDER HISTORY", style = MaterialTheme.typography.titleMedium)
        if (bills.isEmpty()) Text("No bills found for this customer.")
        bills.forEach { bill ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(bill.billNumber, style = MaterialTheme.typography.titleMedium)
                        Text("₹${bill.totalPaise / 100}")
                    }
                    Text(formatDateTime(bill.createdAt))
                    Text("${bill.platform} • ${bill.paymentSummary(db, bill.id)}")
                }
            }
        }
    }
}

private suspend fun Bill.paymentSummary(db: AppDatabase, billId: String): String =
    db.paymentDao().forBill(billId).joinToString(" + ") { "${it.method}: ₹${it.amountPaise / 100}" }

@Composable
private fun OrderHistory(db: AppDatabase, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var bills by remember { mutableStateOf<List<Bill>>(emptyList()) }
    var selected by remember { mutableStateOf<Bill?>(null) }
    LaunchedEffect(Unit) { bills = db.billDao().recent(200) }
    selected?.let { bill ->
        BillDetails(db, bill, onBack = { selected = null })
        return
    }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("ORDER HISTORY", style = MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick = onBack) { Text("BACK") }
        }
        Text("Showing the latest ${bills.size} saved bills. Every bill remains stored locally even when sync, printing or WhatsApp is unavailable.")
        if (bills.isEmpty()) Text("No bills yet.")
        bills.forEach { bill ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(bill.billNumber, style = MaterialTheme.typography.titleMedium)
                        Text("₹${bill.totalPaise / 100}", style = MaterialTheme.typography.titleMedium)
                    }
                    Text("${formatDateTime(bill.createdAt)} • ${bill.platform}")
                    Text("Sync: ${bill.syncStatus} • Print: ${bill.printStatus} • WhatsApp: ${bill.whatsappStatus}")
                    Button(onClick = { selected = bill }, modifier = Modifier.fillMaxWidth()) { Text("VIEW BILL") }
                }
            }
        }
    }
}

@Composable
private fun BillDetails(db: AppDatabase, bill: Bill, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<BillItem>>(emptyList()) }
    var charges by remember { mutableStateOf<List<CustomCharge>>(emptyList()) }
    var payments by remember { mutableStateOf<List<Payment>>(emptyList()) }
    var logs by remember { mutableStateOf<List<AuditLog>>(emptyList()) }
    var editing by remember { mutableStateOf(false) }
    fun refresh() = scope.launch {
        items = db.billItemDao().forBill(bill.id)
        charges = db.customChargeDao().forBill(bill.id)
        payments = db.paymentDao().forBill(bill.id)
        logs = db.auditLogDao().forBill(bill.id)
    }
    LaunchedEffect(bill.id) { refresh() }
    if (editing) {
        BillEditor(db, bill, items, charges, payments, onCancel = { editing = false }, onSaved = { editing = false; refresh() })
        return
    }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("BILL DETAILS", style = MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick = onBack) { Text("BACK") }
        }
        Text(bill.billNumber, style = MaterialTheme.typography.titleLarge)
        Text(formatDateTime(bill.createdAt))
        Text("Order source: ${bill.platform}")
        HorizontalDivider()
        Text("ITEMS", style = MaterialTheme.typography.titleMedium)
        items.forEach { item ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${item.itemNameSnapshot}${item.variantSnapshot?.let { " • $it" } ?: ""} × ${item.quantity}", Modifier.weight(1f))
                Text("₹${item.lineTotalPaise / 100}")
            }
        }
        charges.forEach { charge ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${charge.description} × ${charge.quantity}", Modifier.weight(1f))
                Text("₹${charge.amountPaise * charge.quantity / 100}")
            }
        }
        HorizontalDivider()
        Text("Subtotal: ₹${bill.subtotalPaise / 100}")
        Text("Custom charges: ₹${bill.customChargesPaise / 100}")
        Text("TOTAL: ₹${bill.totalPaise / 100}", style = MaterialTheme.typography.headlineSmall)
        Text("PAYMENT", style = MaterialTheme.typography.titleMedium)
        payments.forEach { Text("${it.method}: ₹${it.amountPaise / 100}") }
        Text("Created by staff ID: ${bill.createdByStaffId}")
        Text("Updated by: ${bill.updatedByStaffId ?: "—"}")
        Text("Print status: ${bill.printStatus}")
        if (message.isNotBlank()) Text(message, color = if (message.startsWith("Printed")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        Text("WhatsApp status: ${bill.whatsappStatus}")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { scope.launch { val ps = PrinterSettings.load(context); val r = PrinterManager.print(context, ps, bill, items, charges, payments); db.billDao().update(bill.copy(printStatus = if (r.isSuccess) "PRINTED" else "FAILED")); message = if (r.isSuccess) "Printed successfully" else "Print failed: ${r.exceptionOrNull()?.message ?: "check printer settings"}" } }, modifier = Modifier.weight(1f)) { Text("REPRINT") }
            Button(onClick = { editing = true }, modifier = Modifier.weight(1f)) { Text("EDIT BILL") }
        }
        Text("EDIT HISTORY", style = MaterialTheme.typography.titleMedium)
        if (logs.isEmpty()) Text("No audit entries yet.")
        logs.forEach { log ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(log.action, style = MaterialTheme.typography.labelLarge)
                    Text(formatDateTime(log.createdAt))
                    Text("Staff: ${log.actorStaffId}")
                    Text(log.details)
                }
            }
        }
    }
}

@Composable
private fun BillEditor(
    db: AppDatabase,
    bill: Bill,
    originalItems: List<BillItem>,
    originalCharges: List<CustomCharge>,
    originalPayments: List<Payment>,
    onCancel: () -> Unit,
    onSaved: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var items by remember(originalItems) { mutableStateOf(originalItems.map { BillEditItem(it.itemNameSnapshot, it.variantSnapshot, it.menuItemId, it.quantity, it.unitPricePaise) }) }
    var charges by remember(originalCharges) { mutableStateOf(originalCharges.map { BillEditCharge(it.description, it.quantity, it.amountPaise) }) }
    var payment by remember(originalPayments) { mutableStateOf(originalPayments.firstOrNull()?.method ?: "Cash") }
    var paymentAmount by remember(originalPayments) { mutableStateOf(originalPayments.sumOf { it.amountPaise }.toString()) }
    var platform by remember(bill) { mutableStateOf(bill.platform) }
    var error by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    val subtotal = items.sumOf { it.unitPricePaise * it.quantity }
    val customTotal = charges.sumOf { it.amountPaise * it.quantity }
    val total = subtotal + customTotal
    val changed = items.map { "${it.name}|${it.variant}|${it.quantity}|${it.unitPricePaise}" }.joinToString(";") != originalItems.map { "${it.itemNameSnapshot}|${it.variantSnapshot}|${it.quantity}|${it.unitPricePaise}" }.joinToString(";") ||
        charges.map { "${it.description}|${it.quantity}|${it.amountPaise}" }.joinToString(";") != originalCharges.map { "${it.description}|${it.quantity}|${it.amountPaise}" }.joinToString(";") || total != bill.totalPaise || platform != bill.platform || (originalPayments.sumOf { it.amountPaise } != paymentAmount.toLongOrNull()) || (originalPayments.firstOrNull()?.method != payment)
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("EDIT BILL ${bill.billNumber}", style = MaterialTheme.typography.headlineSmall); OutlinedButton(onClick = onCancel) { Text("CANCEL") } }
        Text("Changes are recorded in the audit trail; the original bill remains represented by its prior audit entry.", style = MaterialTheme.typography.bodySmall)
        Text("ITEMS", style = MaterialTheme.typography.titleMedium)
        items.forEachIndexed { i, line ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("${line.name}${line.variant?.let { " • $it" } ?: ""}")
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Qty: ${line.quantity}", Modifier.weight(1f))
                    TextButton(onClick = { items = items.toMutableList().also { it[i] = line.copy(quantity = line.quantity - 1) }.filter { it.quantity > 0 } }) { Text("−") }
                    TextButton(onClick = { items = items.toMutableList().also { it[i] = line.copy(quantity = line.quantity + 1) } }) { Text("+") }
                    Text("₹${line.unitPricePaise * line.quantity / 100}")
                }
            }}
        }
        Text("CUSTOM CHARGES", style = MaterialTheme.typography.titleMedium)
        charges.forEachIndexed { i, c ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(c.description, { v -> charges = charges.toMutableList().also { it[i] = c.copy(description = v) } }, label = { Text("Description") }, modifier = Modifier.weight(1f))
                OutlinedTextField((c.amountPaise / 100.0).toString().removeSuffix(".0"), { v -> charges = charges.toMutableList().also { it[i] = c.copy(amountPaise = (v.toDoubleOrNull()?.times(100))?.toLong() ?: 0) } }, label = { Text("₹") }, modifier = Modifier.width(100.dp))
                TextButton(onClick = { charges = charges.toMutableList().also { it.removeAt(i) } }) { Text("REMOVE") }
            }
        }
        Button(onClick = { charges = charges + BillEditCharge("Extra charge", 1, 0) }) { Text("+ CUSTOM CHARGE") }
        Text("ORDER SOURCE", style = MaterialTheme.typography.titleMedium)
        ChoiceRow(listOf("Outlet", "WhatsApp", "Zomato", "Swiggy", "Direct Online", "Other Online"), platform) { platform = it }
        Text("PAYMENT", style = MaterialTheme.typography.titleMedium)
        ChoiceRow(listOf("Cash", "UPI", "Card", "Other"), payment) { payment = it }
        OutlinedTextField(paymentAmount.toLongOrNull()?.let { (it / 100.0).toString().removeSuffix(".0") } ?: "", { v -> paymentAmount = ((v.toDoubleOrNull() ?: 0.0) * 100).toLong().toString() }, label = { Text("Payment amount ₹") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("NEW TOTAL: ₹${total / 100}", style = MaterialTheme.typography.headlineSmall)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Button(enabled = !saving && changed && items.isNotEmpty() && total > 0, onClick = {
            scope.launch {
                saving = true; error = ""
                val actor = db.staffDao().all().firstOrNull { it.role == "ADMIN" && it.active }
                if (actor == null) { error = "No active admin account available"; saving = false; return@launch }
                val paid = paymentAmount.toLongOrNull() ?: 0
                if (paid != total) { error = "Payment amount must equal new bill total"; saving = false; return@launch }
                if (charges.any { it.description.isBlank() || it.amountPaise < 0 }) { error = "Custom charge description/amount is invalid"; saving = false; return@launch }
                val now = System.currentTimeMillis()
                val oldSnapshot = "oldTotal=${bill.totalPaise};oldItems=${originalItems.joinToString { "${it.itemNameSnapshot}x${it.quantity}@${it.unitPricePaise}" }};oldCharges=${originalCharges.joinToString { "${it.description}x${it.quantity}@${it.amountPaise}" }};oldPayment=${originalPayments.joinToString { "${it.method}:${it.amountPaise}" }}"
                val newSnapshot = "newTotal=$total;newItems=${items.joinToString { "${it.name}x${it.quantity}@${it.unitPricePaise}" }};newCharges=${charges.joinToString { "${it.description}x${it.quantity}@${it.amountPaise}" }};newPayment=$payment:$paid;platform=$platform"
                db.billItemDao().deleteForBill(bill.id)
                db.customChargeDao().deleteForBill(bill.id)
                db.paymentDao().deleteForBill(bill.id)
                db.billItemDao().insertAll(items.map { BillItem(UUID.randomUUID().toString(), bill.id, it.menuItemId, it.name, it.variant, it.quantity, it.unitPricePaise, it.unitPricePaise * it.quantity) })
                db.customChargeDao().insertAll(charges.map { CustomCharge(UUID.randomUUID().toString(), bill.id, it.description, it.quantity, it.amountPaise, actor.id, now) })
                db.paymentDao().insertAll(listOf(Payment(UUID.randomUUID().toString(), bill.id, payment, paid)))
                db.billDao().update(bill.copy(platform = platform, subtotalPaise = subtotal, customChargesPaise = customTotal, totalPaise = total, updatedByStaffId = actor.id, updatedAt = now, printStatus = "PENDING", whatsappStatus = "NOT_SENT"))
                db.auditLogDao().insert(AuditLog(UUID.randomUUID().toString(), bill.id, actor.id, "BILL_EDITED", "$oldSnapshot;$newSnapshot", now))
                onSaved()
                saving = false
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (saving) "SAVING…" else "SAVE BILL CHANGES") }
    }
}

private data class BillEditItem(val name: String, val variant: String?, val menuItemId: String?, val quantity: Int, val unitPricePaise: Long)
private data class BillEditCharge(val description: String, val quantity: Int, val amountPaise: Long)

@Composable
private fun PrinterSettingsScreen(onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var settings by remember { mutableStateOf(PrinterSettings.load(context)) }
    var devices by remember { mutableStateOf(PrinterManager.pairedPrinters(context)) }
    var error by remember { mutableStateOf("") }
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { granted -> if (granted) devices = PrinterManager.pairedPrinters(context) else error = "Bluetooth permission is required to see paired printers." }
    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("PRINTER SETTINGS", style = MaterialTheme.typography.headlineSmall); OutlinedButton(onClick=onBack){Text("BACK")} }
        Row(verticalAlignment=Alignment.CenterVertically){ Switch(settings.enabled,{ settings=settings.copy(enabled=it); PrinterSettings.save(context,settings)}); Text("Enable Bluetooth printer") }
        Text("Selected: ${settings.deviceName ?: "No printer selected"}")
        Button(onClick={ if (android.os.Build.VERSION.SDK_INT>=31 && !PrinterManager.hasConnectPermission(context)) permissionLauncher.launch(android.Manifest.permission.BLUETOOTH_CONNECT) else devices=PrinterManager.pairedPrinters(context) }, modifier=Modifier.fillMaxWidth()){Text("REFRESH PAIRED PRINTERS")}
        if(devices.isEmpty()) Text("Pair your thermal printer in Android Bluetooth settings first, then refresh.")
        devices.forEach { d -> OutlinedButton(onClick={ settings=settings.copy(deviceAddress=d.address,deviceName=d.name ?: d.address,enabled=true);PrinterSettings.save(context,settings) },modifier=Modifier.fillMaxWidth()){Text("${d.name ?: "Unknown"} • ${d.address}")} }
        Text("Paper width",style=MaterialTheme.typography.titleMedium); ChoiceRow(listOf("58 mm","80 mm"),"${settings.paperWidth} mm"){settings=settings.copy(paperWidth=if(it.startsWith("80"))80 else 58);PrinterSettings.save(context,settings)}
        Text("Copies",style=MaterialTheme.typography.titleMedium); ChoiceRow(listOf("1","2","3"),settings.copies.toString()){settings=settings.copy(copies=it.toInt());PrinterSettings.save(context,settings)}
        Row(verticalAlignment=Alignment.CenterVertically){ Switch(settings.autoPrint,{settings=settings.copy(autoPrint=it);PrinterSettings.save(context,settings)}); Text("Automatically print after Save Bill") }
        Button(enabled=settings.deviceAddress!=null,onClick={val r=PrinterManager.print(context,settings,Bill("test","TEST-0001",null,"Outlet",0,0,0,"test",null,System.currentTimeMillis(),System.currentTimeMillis()),emptyList(),emptyList(),listOf(Payment("p","test","TEST",0)));error=if(r.isSuccess)"Test print sent" else "Test print failed: ${r.exceptionOrNull()?.message ?: "unknown error"}"},modifier=Modifier.fillMaxWidth()){Text("TEST PRINT")}
        if(error.isNotBlank()) Text(error,color=if(error.startsWith("Test print sent"))MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        Text("The bill is saved before printing. If the printer is unavailable, the bill remains safe and can be retried.",style=MaterialTheme.typography.bodySmall)
    }
}

private fun formatDateTime(time: Long): String = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(time))

@Composable
private fun WhatsAppSettingsScreen(db: AppDatabase, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(WhatsAppSettings()) }
    var message by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { settings = (db.whatsappSettingsDao().get() ?: WhatsAppSettings()).copy(accessToken = SecureSecrets.getWhatsAppToken(context)) }
    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("WHATSAPP BUSINESS", style = MaterialTheme.typography.headlineSmall)
            OutlinedButton(onClick = onBack) { Text("BACK") }
        }
        Text("Official Meta WhatsApp Business Platform/API. Credentials stay on this device until a secure cloud backend is connected.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(settings.businessPhone, { settings = settings.copy(businessPhone = it.filter(Char::isDigit).take(15)) }, label = { Text("Guffh Oven business WhatsApp number") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(settings.phoneNumberId, { settings = settings.copy(phoneNumberId = it.trim()) }, label = { Text("Meta Phone Number ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(settings.accessToken, { settings = settings.copy(accessToken = it.trim()) }, label = { Text("Meta access token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Text("Default bill behavior", style = MaterialTheme.typography.titleMedium)
        ChoiceRow(listOf("ASK", "AUTO_SEND", "NEVER"), settings.defaultMode) { settings = settings.copy(defaultMode = it) }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(settings.enabled, { settings = settings.copy(enabled = it) }); Text("Enable WhatsApp integration") }
        if (message.isNotBlank()) Text(message, color = if (message.startsWith("Saved")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        Button(onClick = { scope.launch { SecureSecrets.setWhatsAppToken(context, settings.accessToken); db.whatsappSettingsDao().save(settings.copy(accessToken = "")); message = "Saved WhatsApp settings" } }, modifier = Modifier.fillMaxWidth()) { Text("SAVE SETTINGS") }
        Text("AUTO_SEND requires a valid customer phone number. If sending fails, the bill remains saved and can be retried.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable private fun StaffHome(db:AppDatabase,staff:Staff,onLogout:()->Unit){var billing by remember{mutableStateOf(false)};if(billing)NewBillScreen(db,staff,{billing=false})else Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.spacedBy(18.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("GUFFH OVEN",style=MaterialTheme.typography.headlineLarge);Text("STAFF BILLING",style=MaterialTheme.typography.headlineSmall);if(staff.canCreateBills)Button(onClick={billing=true},modifier=Modifier.fillMaxWidth()){Text("NEW BILL")}else Text("Your account is not permitted to create bills.");OutlinedButton(onClick=onLogout){Text("LOG OUT")}}}

@Composable private fun NewBillScreen(db:AppDatabase,staff:Staff,onBack:()->Unit){val scope=rememberCoroutineScope();var phone by remember{mutableStateOf("")};var customerName by remember{mutableStateOf("")};var existingCustomer by remember{mutableStateOf<Customer?>(null)};var noPhone by remember{mutableStateOf(false)};var items by remember{mutableStateOf<List<MenuItem>>(emptyList())};var cart by remember{mutableStateOf<List<CartLine>>(emptyList())};var charges by remember{mutableStateOf<List<ChargeDraft>>(emptyList())};var platform by remember{mutableStateOf("Outlet")};var payment by remember{mutableStateOf("Cash")};var cash by remember{mutableStateOf("")};var upi by remember{mutableStateOf("")};var card by remember{mutableStateOf("")};var other by remember{mutableStateOf("")};var sendWhatsApp by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")};var saved by remember{mutableStateOf(false)};var savedBill by remember{mutableStateOf<Bill?>(null)};val context=androidx.compose.ui.platform.LocalContext.current
LaunchedEffect(Unit){items=db.menuItemDao().activeItems(); val ws=db.whatsappSettingsDao().get(); sendWhatsApp = ws?.defaultMode == "AUTO_SEND"}
LaunchedEffect(phone,noPhone){if(noPhone){existingCustomer=null;return@LaunchedEffect};if(phone.length>=10){existingCustomer=db.customerDao().findByPhone(phone.filter(Char::isDigit))}}
if(saved){Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.spacedBy(16.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("BILL SAVED",style=MaterialTheme.typography.headlineSmall);Text("The bill is stored locally and marked for sync."); val ps=PrinterSettings.load(context); if(savedBill!=null && ps.enabled && staff.canPrint){Button(onClick={scope.launch{val b=savedBill!!;val r=PrinterManager.print(context,ps,b,db.billItemDao().forBill(b.id),db.customChargeDao().forBill(b.id),db.paymentDao().forBill(b.id));db.billDao().update(b.copy(printStatus=if(r.isSuccess) "PRINTED" else "FAILED"))}}){Text("RETRY PRINT")}};Text("Printing or WhatsApp failure never deletes the saved bill.");Button(onClick=onBack){Text("DONE")}};return}
val subtotal=cart.sumOf{it.item.pricePaise*it.quantity};val chargeTotal=charges.sumOf{it.amountPaise*it.quantity};val total=subtotal+chargeTotal
Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("NEW BILL",style=MaterialTheme.typography.headlineSmall);OutlinedButton(onClick=onBack){Text("BACK")}};Text("CUSTOMER",style=MaterialTheme.typography.titleMedium);OutlinedTextField(phone,{phone=it.filter(Char::isDigit).take(10)},label={Text("Phone (optional)")},enabled=!noPhone,singleLine=true,modifier=Modifier.fillMaxWidth());Row(verticalAlignment=Alignment.CenterVertically){Checkbox(noPhone,{noPhone=it});Text("Customer doesn't want to share phone")};if(existingCustomer!=null)Text("Existing customer: ${existingCustomer!!.name ?: "Customer"}");if(phone.length>=10&&!noPhone&&existingCustomer==null)OutlinedTextField(customerName,{customerName=it},label={Text("Customer name (new customer)")},singleLine=true,modifier=Modifier.fillMaxWidth())
Text("MENU",style=MaterialTheme.typography.titleMedium);if(items.isEmpty())Text("No active menu items yet. Add your final menu in Menu Management before taking itemized orders.") else items.forEach{item->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Column(Modifier.weight(1f)){Text(item.name);if(item.variant!=null)Text(item.variant!!,style=MaterialTheme.typography.bodySmall);Text("₹${item.pricePaise/100}")};Button(onClick={cart=cart.addOne(item)}){Text("ADD")}}};cart.forEachIndexed{idx,line->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("${line.item.name} × ${line.quantity}",Modifier.weight(1f));Text("₹${line.item.pricePaise*line.quantity/100}");TextButton(onClick={cart=cart.toMutableList().also{it[idx]=line.copy(quantity=line.quantity-1)}.filter{it.quantity>0}}){Text("−")};TextButton(onClick={cart=cart.toMutableList().also{it[idx]=line.copy(quantity=line.quantity+1)}}){Text("+")}}}
if(staff.canAddCustomCharges){Text("CUSTOM CHARGES",style=MaterialTheme.typography.titleMedium);Button(onClick={charges=charges+ChargeDraft("Extra charge",1,0)}){Text("+ CUSTOM CHARGE")};charges.forEachIndexed{idx,ch->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(ch.description,{v->charges=charges.toMutableList().also{it[idx]=ch.copy(description=v)}},label={Text("Description")},modifier=Modifier.weight(1f));OutlinedTextField(ch.amountPaise.toString().removeSuffix("00"),{v->val paise=(v.toDoubleOrNull()?.times(100))?.toLong()?:0;charges=charges.toMutableList().also{it[idx]=ch.copy(amountPaise=paise)}},label={Text("₹")},modifier=Modifier.width(100.dp))}}}
Text("ORDER SOURCE",style=MaterialTheme.typography.titleMedium);ChoiceRow(listOf("Outlet","WhatsApp","Zomato","Swiggy","Direct Online","Other Online"),platform){platform=it};Text("PAYMENT",style=MaterialTheme.typography.titleMedium);ChoiceRow(listOf("Cash","UPI","Card","Other","Split Payment"),payment){payment=it};if(payment=="Split Payment"){Text("Enter amounts; total must equal ₹${total/100}");PaymentField("Cash",cash){cash=it};PaymentField("UPI",upi){upi=it};PaymentField("Card",card){card=it};PaymentField("Other",other){other=it}}
if(staff.canSendWhatsApp){Row(verticalAlignment=Alignment.CenterVertically){Checkbox(sendWhatsApp,{sendWhatsApp=it},enabled=!noPhone&&phone.length==10);Text("Send itemized bill on WhatsApp")}}
Text("TOTAL ₹${total/100}",style=MaterialTheme.typography.headlineSmall);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);Button(onClick={scope.launch{error="";if(cart.isEmpty()&&charges.isEmpty()){error="Add at least one item or custom charge";return@launch};if(sendWhatsApp&&(!phone.matches(Regex("\\d{10}")))){error="Enter a valid 10-digit phone number for WhatsApp";return@launch};val payments=if(payment=="Split Payment")listOf("Cash" to cash,"UPI" to upi,"Card" to card,"Other" to other).mapNotNull{(m,v)->val p=(v.toDoubleOrNull()?.times(100))?.toLong()?:0;if(p>0)m to p else null}else listOf(payment to total);if(payments.sumOf{it.second}!=total){error="Payment amount must equal bill total";return@launch};val now=System.currentTimeMillis();val customerId=if(noPhone){val id=UUID.randomUUID().toString();db.customerDao().insert(Customer(id,null,null,true,now,now,now,1,total));id}else{val normalized=phone.filter(Char::isDigit);if(normalized.length==10){val c=existingCustomer;if(c==null){val id=UUID.randomUUID().toString();db.customerDao().insert(Customer(id,customerName.trim().ifBlank{null},normalized,false,now,now,now,1,total));id}else{db.customerDao().update(c.copy(lastVisitAt=now,totalVisits=c.totalVisits+1,totalSpendingPaise=c.totalSpendingPaise+total));c.id}}else null};val billId=UUID.randomUUID().toString();val billNo="GO-${now}";val bill=Bill(billId,billNo,customerId,platform,subtotal,chargeTotal,total,staff.id,staff.id,now,now);db.billDao().insert(bill);db.billItemDao().insertAll(cart.map{BillItem(UUID.randomUUID().toString(),billId,it.item.id,it.item.name,it.item.variant,it.quantity,it.item.pricePaise,it.item.pricePaise*it.quantity)});db.customChargeDao().insertAll(charges.map{CustomCharge(UUID.randomUUID().toString(),billId,it.description,it.quantity,it.amountPaise,staff.id,now)});db.paymentDao().insertAll(payments.map{Payment(UUID.randomUUID().toString(),billId,it.first,it.second)});db.auditLogDao().insert(AuditLog(UUID.randomUUID().toString(),billId,staff.id,"BILL_CREATED","total=$total platform=$platform whatsappRequested=$sendWhatsApp",now));val syncPayload=org.json.JSONObject().apply{put("id",billId);put("billNumber",billNo);put("customerId",customerId ?: org.json.JSONObject.NULL);put("platform",platform);put("subtotalPaise",subtotal);put("customChargesPaise",chargeTotal);put("totalPaise",total);put("createdByStaffId",staff.id);put("updatedAt",now)};SyncManager(context,db).enqueue("BILL",billId,"UPSERT",syncPayload);
val ws = db.whatsappSettingsDao().get()
if (sendWhatsApp && ws != null) {
    val recipient = phone.filter(Char::isDigit)
    val result = WhatsAppManager.send(ws.copy(accessToken = SecureSecrets.getWhatsAppToken(context)), recipient, WhatsAppManager.messageFor(bill, db.billItemDao().forBill(billId), db.customChargeDao().forBill(billId), db.paymentDao().forBill(billId)))
    db.billDao().update(bill.copy(whatsappStatus = if (result.isSuccess) "SENT" else "FAILED"))
    db.auditLogDao().insert(AuditLog(UUID.randomUUID().toString(), billId, staff.id, if (result.isSuccess) "WHATSAPP_SENT" else "WHATSAPP_FAILED", result.exceptionOrNull()?.message ?: "sent", System.currentTimeMillis()))
}
savedBill = db.billDao().findById(billId) ?: bill
val ps=PrinterSettings.load(context); val latestBill = db.billDao().findById(billId) ?: bill; if (staff.canPrint && ps.enabled && ps.autoPrint) { val r=PrinterManager.print(context,ps,latestBill,db.billItemDao().forBill(billId),db.customChargeDao().forBill(billId),db.paymentDao().forBill(billId)); db.billDao().update(latestBill.copy(printStatus=if(r.isSuccess) "PRINTED" else "FAILED")) }; saved=true}},modifier=Modifier.fillMaxWidth()){Text("SAVE BILL")}}
}

private fun List<CartLine>.addOne(item:MenuItem):List<CartLine>{val old=firstOrNull{it.item.id==item.id};return if(old==null)this+CartLine(item,1) else map{if(it.item.id==item.id)it.copy(quantity=it.quantity+1)else it}}
@Composable private fun ChoiceRow(options:List<String>,selected:String,onSelect:(String)->Unit){Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){options.forEach{OutlinedButton(onClick={onSelect(it)}){Text(if(it==selected)"✓ $it" else it)}}}}
@Composable private fun PaymentField(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth())}
