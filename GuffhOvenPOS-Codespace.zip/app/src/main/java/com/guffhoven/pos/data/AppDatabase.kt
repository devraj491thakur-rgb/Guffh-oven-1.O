package com.guffhoven.pos.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Staff::class, Customer::class, MenuItem::class, Bill::class, BillItem::class, Payment::class, CustomCharge::class, AuditLog::class, WhatsAppSettings::class, SyncSettings::class, SyncQueueEntry::class],
    version = 4,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun staffDao(): StaffDao
    abstract fun customerDao(): CustomerDao
    abstract fun menuItemDao(): MenuItemDao
    abstract fun billDao(): BillDao
    abstract fun billItemDao(): BillItemDao
    abstract fun paymentDao(): PaymentDao
    abstract fun customChargeDao(): CustomChargeDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun whatsappSettingsDao(): WhatsAppSettingsDao
    abstract fun syncSettingsDao(): SyncSettingsDao
    abstract fun syncQueueDao(): SyncQueueDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE staff ADD COLUMN canCreateBills INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE staff ADD COLUMN canAddCustomCharges INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE staff ADD COLUMN canEditRecentBills INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE staff ADD COLUMN canPrint INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE staff ADD COLUMN canSendWhatsApp INTEGER NOT NULL DEFAULT 1")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS whatsapp_settings (id INTEGER NOT NULL, businessPhone TEXT NOT NULL, accessToken TEXT NOT NULL, phoneNumberId TEXT NOT NULL, defaultMode TEXT NOT NULL, enabled INTEGER NOT NULL, apiBaseUrl TEXT NOT NULL, PRIMARY KEY(id))")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS sync_settings (id INTEGER NOT NULL, enabled INTEGER NOT NULL, serverUrl TEXT NOT NULL, deviceId TEXT NOT NULL, lastSyncAt INTEGER, lastSyncStatus TEXT NOT NULL, PRIMARY KEY(id))")
                db.execSQL("CREATE TABLE IF NOT EXISTS sync_queue (id TEXT NOT NULL, entityType TEXT NOT NULL, entityId TEXT NOT NULL, operation TEXT NOT NULL, payloadJson TEXT NOT NULL, createdAt INTEGER NOT NULL, attempts INTEGER NOT NULL, status TEXT NOT NULL, lastError TEXT, PRIMARY KEY(id))")
            }
        }

        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "guffh_oven_pos.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build().also { INSTANCE = it }
        }
    }
}
