package com.guffhoven.pos

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import com.guffhoven.pos.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SyncConnectivity(private val context: Context, private val db: AppDatabase) {
    private val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            CoroutineScope(Dispatchers.IO).launch { SyncManager(context, db).syncOnce() }
        }
    }
    fun start() { manager.registerDefaultNetworkCallback(callback) }
    fun stop() { runCatching { manager.unregisterNetworkCallback(callback) } }
}
