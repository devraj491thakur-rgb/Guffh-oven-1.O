package com.guffhoven.pos

import android.content.Context
import com.guffhoven.pos.data.AppDatabase
import com.guffhoven.pos.data.SyncQueueEntry
import com.guffhoven.pos.data.SyncSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Offline-first synchronization foundation.
 * The serverUrl must point to the future Guffh Oven backend; credentials/tokens
 * are intentionally not embedded in the APK.
 */
class SyncManager(private val context: Context, private val db: AppDatabase) {
    suspend fun deviceId(): String {
        val current = db.syncSettingsDao().get()
        if (current?.deviceId?.isNotBlank() == true) return current.deviceId
        val id = UUID.randomUUID().toString()
        db.syncSettingsDao().save(current?.copy(deviceId = id) ?: SyncSettings(deviceId = id))
        return id
    }

    suspend fun enqueue(entityType: String, entityId: String, operation: String, payload: JSONObject) {
        db.syncQueueDao().enqueue(
            SyncQueueEntry(UUID.randomUUID().toString(), entityType, entityId, operation, payload.toString(), System.currentTimeMillis())
        )
    }

    suspend fun pendingCount(): Int = db.syncQueueDao().pendingCount()

    suspend fun syncOnce(): Result<Int> = withContext(Dispatchers.IO) {
        val settings = db.syncSettingsDao().get() ?: return@withContext Result.failure(IllegalStateException("Cloud sync is not configured"))
        if (!settings.enabled || settings.serverUrl.isBlank()) return@withContext Result.failure(IllegalStateException("Cloud sync is disabled or server URL is missing"))
        val entries = db.syncQueueDao().pending(50)
        if (entries.isEmpty()) {
            db.syncSettingsDao().save(settings.copy(lastSyncAt = System.currentTimeMillis(), lastSyncStatus = "SYNCED"))
            return@withContext Result.success(0)
        }
        try {
            val connection = (URL(settings.serverUrl.trimEnd('/') + "/v1/sync/push").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 15_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                SecureSecrets.getSyncToken(context).takeIf { it.isNotBlank() }?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            val body = JSONObject().apply {
                put("deviceId", settings.deviceId)
                put("entries", org.json.JSONArray(entries.map { it.payloadJson }))
            }.toString()
            connection.outputStream.use { it.write(body.toByteArray()) }
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("Sync server returned HTTP $code")
            entries.forEach { db.syncQueueDao().update(it.copy(status = "SYNCED", lastError = null)) }
            db.syncSettingsDao().save(settings.copy(lastSyncAt = System.currentTimeMillis(), lastSyncStatus = "SYNCED"))
            Result.success(entries.size)
        } catch (e: Exception) {
            entries.forEach { db.syncQueueDao().update(it.copy(attempts = it.attempts + 1, lastError = e.message)) }
            db.syncSettingsDao().save(settings.copy(lastSyncStatus = "FAILED"))
            Result.failure(e)
        }
    }

    suspend fun pullOnce(limit: Int = 200): Result<List<JSONObject>> = withContext(Dispatchers.IO) {
        val settings = db.syncSettingsDao().get()
            ?: return@withContext Result.failure(IllegalStateException("Cloud sync is not configured"))
        if (!settings.enabled || settings.serverUrl.isBlank())
            return@withContext Result.failure(IllegalStateException("Cloud sync is disabled or server URL is missing"))
        try {
            val url = URL(settings.serverUrl.trimEnd('/') + "/v1/sync/pull?limit=" + limit)
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10_000
                readTimeout = 15_000
                setRequestProperty("Accept", "application/json")
                SecureSecrets.getSyncToken(context).takeIf { it.isNotBlank() }?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("Pull server returned HTTP $code")
            val text = connection.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            val records = root.optJSONArray("records") ?: org.json.JSONArray()
            val result = buildList {
                for (i in 0 until records.length()) add(records.getJSONObject(i))
            }
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

