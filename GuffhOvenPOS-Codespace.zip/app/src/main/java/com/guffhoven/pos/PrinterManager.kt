package com.guffhoven.pos

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.guffhoven.pos.data.*
import java.io.OutputStream
import java.util.UUID

object PrinterManager {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun hasConnectPermission(context: Context): Boolean =
        android.os.Build.VERSION.SDK_INT < 31 || ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    fun pairedPrinters(context: Context): List<BluetoothDevice> {
        if (!hasConnectPermission(context)) return emptyList()
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        return adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
    }

    fun print(context: Context, settings: PrinterSettings, bill: Bill, items: List<BillItem>, charges: List<CustomCharge>, payments: List<Payment>): Result<Unit> {
        if (!settings.enabled) return Result.failure(IllegalStateException("Printer is disabled"))
        if (!hasConnectPermission(context)) return Result.failure(SecurityException("Bluetooth permission is required"))
        val address = settings.deviceAddress ?: return Result.failure(IllegalStateException("No printer selected"))
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return Result.failure(IllegalStateException("Bluetooth is unavailable"))
        val device = adapter.getRemoteDevice(address)
        var socket: BluetoothSocket? = null
        return try {
            socket = device.createRfcommSocketToServiceRecord(sppUuid)
            adapter.cancelDiscovery()
            socket.connect()
            val out = socket.outputStream
            repeat(settings.copies.coerceIn(1, 3)) { writeReceipt(out, settings.paperWidth, bill, items, charges, payments) }
            out.flush()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
        finally { try { socket?.close() } catch (_: Exception) {} }
    }

    private fun writeReceipt(out: OutputStream, width: Int, bill: Bill, items: List<BillItem>, charges: List<CustomCharge>, payments: List<Payment>) {
        val cols = if (width == 58) 32 else 48
        fun line(s: String = "") { out.write((s.take(cols) + "\n").toByteArray(Charsets.UTF_8)) }
        fun two(left: String, right: String) {
            val r = right.take(cols / 2); val l = left.take((cols - r.length - 1).coerceAtLeast(1))
            line(l + " ".repeat((cols - l.length - r.length).coerceAtLeast(1)) + r)
        }
        out.write(byteArrayOf(0x1B, 0x40))
        out.write(byteArrayOf(0x1B, 0x61, 0x01))
        out.write(byteArrayOf(0x1B, 0x45, 0x01)); line("GUFFH OVEN"); out.write(byteArrayOf(0x1B, 0x45, 0x00))
        line("Bill ${bill.billNumber}"); line(formatDateTime(bill.createdAt)); line("-".repeat(cols))
        out.write(byteArrayOf(0x1B, 0x61, 0x00))
        items.forEach { two("${it.itemNameSnapshot} x${it.quantity}", money(it.lineTotalPaise)) }
        charges.forEach { two("${it.description} x${it.quantity}", money(it.amountPaise * it.quantity)) }
        line("-".repeat(cols)); two("TOTAL", money(bill.totalPaise)); line("Payment")
        payments.forEach { two(it.method, money(it.amountPaise)) }
        line("Order: ${bill.platform}"); line("Thank you! Visit again."); line(); line(); line()
        out.write(byteArrayOf(0x1D, 0x56, 0x00))
    }
    private fun money(paise: Long): String = "Rs.${paise / 100}${if (paise % 100 == 0L) "" else ".${(paise % 100).toString().padStart(2,'0')}"}"
    private fun formatDateTime(time: Long): String = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(time))
}

data class PrinterSettings(val enabled: Boolean = false, val deviceAddress: String? = null, val deviceName: String? = null, val paperWidth: Int = 58, val copies: Int = 1, val autoPrint: Boolean = true) {
    companion object {
        private const val PREF = "printer_settings"
        fun load(context: Context): PrinterSettings { val p=context.getSharedPreferences(PREF, Context.MODE_PRIVATE); return PrinterSettings(p.getBoolean("enabled",false),p.getString("address",null),p.getString("name",null),p.getInt("width",58),p.getInt("copies",1),p.getBoolean("auto",true)) }
        fun save(context: Context, s: PrinterSettings) { context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean("enabled",s.enabled).putString("address",s.deviceAddress).putString("name",s.deviceName).putInt("width",s.paperWidth).putInt("copies",s.copies).putBoolean("auto",s.autoPrint).apply() }
    }
}
