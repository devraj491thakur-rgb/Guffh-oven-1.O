package com.guffhoven.pos.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface StaffDao {
    @Query("SELECT * FROM staff WHERE username = :username LIMIT 1")
    suspend fun findByUsername(username: String): Staff?

    @Query("SELECT * FROM staff ORDER BY role ASC, active DESC, name COLLATE NOCASE ASC")
    suspend fun all(): List<Staff>

    @Query("SELECT * FROM staff WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): Staff?

    @Query("SELECT COUNT(*) FROM staff")
    suspend fun count(): Int

    @Insert
    suspend fun insert(staff: Staff)

    @Update
    suspend fun update(staff: Staff)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE phone = :phone LIMIT 1")
    suspend fun findByPhone(phone: String): Customer?

    @Query("SELECT * FROM customers WHERE anonymous = 0 ORDER BY lastVisitAt DESC, name COLLATE NOCASE ASC")
    suspend fun allNamed(): List<Customer>

    @Query("SELECT * FROM customers WHERE anonymous = 0 AND (name LIKE :query OR phone LIKE :query) ORDER BY lastVisitAt DESC")
    suspend fun search(query: String): List<Customer>

    @Insert
    suspend fun insert(customer: Customer)

    @androidx.room.Update
    suspend fun update(customer: Customer)
}

@Dao
interface MenuItemDao {
    @Query("SELECT * FROM menu_items ORDER BY sortOrder, category, name COLLATE NOCASE")
    suspend fun all(): List<MenuItem>

    @Query("SELECT * FROM menu_items WHERE active = 1 ORDER BY sortOrder, category, name COLLATE NOCASE")
    suspend fun activeItems(): List<MenuItem>

    @Insert
    suspend fun insert(item: MenuItem)

    @Insert
    suspend fun insertAll(items: List<MenuItem>)

    @Update
    suspend fun update(item: MenuItem)
}

@Dao
data class SalesSummary(
    val totalPaise: Long,
    val billCount: Int
)

data class ProductSalesSummary(val itemNameSnapshot: String, val quantity: Long, val totalPaise: Long)
data class StaffSalesSummary(val staffId: String, val billCount: Int, val totalPaise: Long)

@Dao
interface BillDao {
    @Insert
    suspend fun insert(bill: Bill)

    @Update
    suspend fun update(bill: Bill)

    @Query("SELECT * FROM bills ORDER BY createdAt DESC LIMIT :limit")
    suspend fun recent(limit: Int): List<Bill>

    @Query("SELECT * FROM bills WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): Bill?

    @Query("SELECT * FROM bills WHERE customerId = :customerId ORDER BY createdAt DESC")
    suspend fun forCustomer(customerId: String): List<Bill>

    @Query("SELECT COALESCE(SUM(totalPaise),0) AS totalPaise, COUNT(*) AS billCount FROM bills WHERE createdAt >= :start AND createdAt < :end")
    suspend fun salesSummary(start: Long, end: Long): SalesSummary

    @Query("SELECT COALESCE(SUM(totalPaise),0) FROM bills WHERE createdAt >= :start AND createdAt < :end AND platform = 'Outlet'")
    suspend fun outletSales(start: Long, end: Long): Long

    @Query("SELECT COALESCE(SUM(totalPaise),0) FROM bills WHERE createdAt >= :start AND createdAt < :end AND platform != 'Outlet'")
    suspend fun onlineSales(start: Long, end: Long): Long

    @Query("SELECT bi.itemNameSnapshot AS itemNameSnapshot, SUM(bi.quantity) AS quantity, COALESCE(SUM(bi.lineTotalPaise),0) AS totalPaise FROM bill_items bi INNER JOIN bills b ON b.id = bi.billId WHERE b.createdAt >= :start AND b.createdAt < :end GROUP BY bi.itemNameSnapshot ORDER BY totalPaise DESC")
    suspend fun productSales(start: Long, end: Long): List<ProductSalesSummary>

    @Query("SELECT b.createdByStaffId AS staffId, COUNT(*) AS billCount, COALESCE(SUM(b.totalPaise),0) AS totalPaise FROM bills b WHERE b.createdAt >= :start AND b.createdAt < :end GROUP BY b.createdByStaffId ORDER BY totalPaise DESC")
    suspend fun staffSales(start: Long, end: Long): List<StaffSalesSummary>

    @Query("SELECT DISTINCT platform FROM bills WHERE createdAt >= :start AND createdAt < :end ORDER BY platform")
    suspend fun platforms(start: Long, end: Long): List<String>

    @Query("SELECT platform AS method, COALESCE(SUM(totalPaise),0) AS totalPaise FROM bills WHERE createdAt >= :start AND createdAt < :end GROUP BY platform ORDER BY totalPaise DESC")
    suspend fun platformSales(start: Long, end: Long): List<PaymentSummary>
}

@Dao
interface BillItemDao {
    @Insert
    suspend fun insertAll(items: List<BillItem>)

    @Query("DELETE FROM bill_items WHERE billId = :billId")
    suspend fun deleteForBill(billId: String)

    @Query("SELECT * FROM bill_items WHERE billId = :billId ORDER BY rowid ASC")
    suspend fun forBill(billId: String): List<BillItem>
}

@Dao
data class PaymentSummary(val method: String, val totalPaise: Long)

@Dao
interface PaymentDao {
    @Insert
    suspend fun insertAll(payments: List<Payment>)

    @Query("DELETE FROM payments WHERE billId = :billId")
    suspend fun deleteForBill(billId: String)

    @Query("SELECT * FROM payments WHERE billId = :billId ORDER BY rowid ASC")
    suspend fun forBill(billId: String): List<Payment>

    @Query("SELECT p.method AS method, COALESCE(SUM(p.amountPaise),0) AS totalPaise FROM payments p INNER JOIN bills b ON b.id = p.billId WHERE b.createdAt >= :start AND b.createdAt < :end GROUP BY p.method ORDER BY totalPaise DESC")
    suspend fun summary(start: Long, end: Long): List<PaymentSummary>
}

@Dao
interface CustomChargeDao {
    @Insert
    suspend fun insertAll(charges: List<CustomCharge>)

    @Query("DELETE FROM custom_charges WHERE billId = :billId")
    suspend fun deleteForBill(billId: String)

    @Query("SELECT * FROM custom_charges WHERE billId = :billId ORDER BY rowid ASC")
    suspend fun forBill(billId: String): List<CustomCharge>
}

@Dao
interface AuditLogDao {
    @Insert
    suspend fun insert(log: AuditLog)

    @Query("SELECT * FROM audit_logs WHERE billId = :billId ORDER BY createdAt DESC")
    suspend fun forBill(billId: String): List<AuditLog>
}

@Dao
interface WhatsAppSettingsDao {
    @Query("SELECT * FROM whatsapp_settings WHERE id = 1 LIMIT 1")
    suspend fun get(): WhatsAppSettings?

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun save(settings: WhatsAppSettings)
}

@Dao
interface SyncSettingsDao {
    @Query("SELECT * FROM sync_settings WHERE id = 1 LIMIT 1")
    suspend fun get(): SyncSettings?

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun save(settings: SyncSettings)
}

@Dao
interface SyncQueueDao {
    @Query("SELECT * FROM sync_queue WHERE status = 'PENDING' ORDER BY createdAt ASC LIMIT :limit")
    suspend fun pending(limit: Int): List<SyncQueueEntry>

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun enqueue(entry: SyncQueueEntry)

    @Update
    suspend fun update(entry: SyncQueueEntry)

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status = 'PENDING'")
    suspend fun pendingCount(): Int

    @Query("DELETE FROM sync_queue WHERE status = 'SYNCED'")
    suspend fun clearSynced()
}
