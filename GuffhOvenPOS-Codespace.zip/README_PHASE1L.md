# Phase 1L — Cloud Backup & Multi-device Sync Foundation

This phase adds the client-side offline-first synchronization foundation.

## Added
- Room v4 schema with `sync_settings` and `sync_queue`.
- Persistent unique device ID.
- Admin Cloud Backup & Sync settings screen.
- HTTPS backend URL configuration.
- Pending sync queue and retry counters.
- Bill creation now queues a bill UPSERT payload immediately after the local transaction.
- Manual `SYNC NOW` action.
- Sync status and pending-record count.
- Bills remain usable offline; cloud failure never blocks local billing.

## Backend contract
The Android client currently posts to:
`POST {serverUrl}/v1/sync/push`

Request shape:
- `deviceId`
- `entries[]` containing the queued payloads.

A production backend must authenticate the device, validate the payload, apply idempotent UPSERT operations, maintain server-side audit history, and return a successful 2xx response only after durable storage.

## Important production limitation
No real cloud provider/backend credentials are embedded in this project. The configured URL must point to a secure Guffh Oven backend that you control. Multi-device conflict resolution, encrypted server storage, authentication tokens, scheduled/background sync, and automated cloud backups require that backend to be deployed and tested before this is considered production-ready.
